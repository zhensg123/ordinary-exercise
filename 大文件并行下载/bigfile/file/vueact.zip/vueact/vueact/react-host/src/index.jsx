import React from 'react';
import ReactDOM from 'react-dom';
import ReactModal from 'react-modal';
import VueStub from './components/vue-stub.jsx';
import './index.less';

export default class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
            title: '选择一个教程'
        };
    }
    componentDidMount() {
        ReactModal.setAppElement(document.body);
    }
    onRequestClose = () => {
        this.setState({
            isOpen: false
        });
    };
    onClose = (ev) => {
        ev.preventDefault();
        this.setState({
            isOpen: false
        });
    };
    openModal(ev, type) {
        ev.preventDefault();
        this.setState({
            isOpen: true,
            title: type === 0 ? '选择一个教程2' : '选择一个教程'
        });
    };
    render() {
        return (
            <div class="x-page">
                <h1>React App</h1>
                <ul>
                    <li><a href="#" onClick={ev => this.openModal(ev, 0)}>open react modal</a></li>
                    <li><a href="#" onClick={ev => this.openModal(ev, 1)}>open custom modal</a></li>
                </ul>
                <VueStub tag="Test" id="test0" props={{ content: '直接使用VueStub(in app)' }} />
                <ReactModal
                    isOpen={this.state.isOpen}
                    contentLabel={this.state.title}
                    onRequestClose={this.onRequestClose}
                >
                    <a href="#" onClick={this.onClose} style={{ position: 'absolute', top: '8px', right: '8px' }}>Close</a>
                    react content
                </ReactModal>
            </div>
        );
    }
}

const root = document.querySelector('#root');
if (root) {
    ReactDOM.render(<App />, root);
}

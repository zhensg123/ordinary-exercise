import React from 'react';
import PropTypes from 'prop-types';
import VueStub from './vue-stub.jsx';
import styles from './react-modal.css';

const ReactModal = window.ReactModal;

export default class Modal extends React.Component {
    static propTypes = {
        isOpen: PropTypes.bool.isRequired,
        className: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.shape({
                base: PropTypes.string.isRequired,
                afterOpen: PropTypes.string.isRequired,
                beforeClose: PropTypes.string.isRequired
            })
        ]),
        contentLabel: PropTypes.string,
        overlayClassName: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.shape({
                base: PropTypes.string.isRequired,
                afterOpen: PropTypes.string.isRequired,
                beforeClose: PropTypes.string.isRequired
            })
        ]),
        onRequestClose: PropTypes.func
    };

    static defaultProps = {
        isOpen: false
    };

    static setAppElement(el) {
        ReactModal.setAppElement(el);
    }

    constructor(props) {
        super(props);
        console.log('props=', props);
        this.state = {
            useVue: props.contentLabel === '选择一个教程',
            visible: props.isOpen
        };
    }

    componentWillReceiveProps(nextProps) {
        console.log('----componentWillReceiveProps', nextProps);
        this.setState({
            useVue: nextProps.contentLabel === '选择一个教程',
            visible: nextProps.isOpen
        });
    }

    handleClose = (ev) => {
        // ev.stopPropagation();
        ev.preventDefault();
        this.props.onRequestClose();
        this.setState({
            visible: false
        });
        // return false;
    };

    render() {
        return this.state.useVue
            ? (
                <div class={styles.xMask} style={{ display: this.state.visible ? 'block' : 'none' }}>
                    <div class={styles.xDialog}>
                        <a class={styles.dialogClose} href="#" onClick={this.handleClose}>Close</a>
                        <VueStub class={styles.dialogContent} tag="Test" id="test1" props={{ content: '直接使用VueStub(in modal)' }} />
                    </div>
                </div>
            )
            : <ReactModal {...this.props} />;
    }
};

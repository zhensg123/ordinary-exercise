import React from "react";
import PropTypes from "prop-types";
const { createVue } = window["vue-embed-app"];

/*
const Test = Vue.component('test', {
    template: `
        <div>
            vue render content
        </div>
    `
});
*/

export default class VueStub extends React.Component {
    static propTypes = {
        id: PropTypes.string,
        className: PropTypes.string, // TODO
        props: PropTypes.object
    };
    constructor(props) {
        super(props);
        console.log('props=', props);
        this.c = null;
        this.container = null;
    }
    componentWillReceiveProps(nextProps) {
        console.log('----componentWillReceiveProps', nextProps);
        this.setState({
            visible: nextProps.isOpen
        });
    }
    componentDidMount() {
        console.log('----componentDidMount', this.c);
        // const c = this.c = new Test();
        const c = this.c = createVue('Test', this.props.props); // TODO cache Vue instance
        console.log('----c=', c);
        c.$mount(this.container);
        // c.$mount();
        // this.container.appendChild(c.$el);
    }
    componentWillUnmount() {
        console.log('----componentWillUnmount');
        const el = this.c.$el;
        // this.container.removeChild(el);
        el.parentNode.replaceChild(this.container, el);
    }
    render() {
        return (
            <div
                ref={el => this.container = el}
                {...this.props.props}
            />
        );
    }
}

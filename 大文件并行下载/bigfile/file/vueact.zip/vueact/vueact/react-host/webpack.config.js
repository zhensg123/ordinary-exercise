const path = require('path');
const webpack = require('webpack');
const { merge } = require('webpack-merge');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
const autoprefixer = require('autoprefixer');
const postcssImport = require('postcss-import');
const cdnpub = require('@xdf/cdnpub');
const { name, version } = require('./package');

const outputBase = '/static/0.1.0';
const cdnStatic = outputBase + '/static';
const STATIC_PATH = process.env.STATIC_PATH || cdnStatic;
const port = process.env.PORT || 7036;

const base = {
    mode: process.env.NODE_ENV === 'production' ? 'production' : 'development',
    devtool: 'cheap-module-source-map',
    devServer: {
        contentBase: path.resolve(__dirname, 'dist' + outputBase),
        // host: '0.0.0.0',
        host: '127.0.0.1',
        port,
        disableHostCheck: true,
        hot: true,
        sockHost: '127.0.0.1',
        sockPort: port,
        index: 'index.html',
        writeToDisk: true
    },
    entry: {
        app: './src/index.jsx'
    },
    output: {
        library: `${name}-[name]`,
        libraryTarget: 'umd',
        filename: 'js/[name].js',
        chunkFilename: 'js/chunks/[name].js',
        path: path.resolve(__dirname, 'dist' + outputBase),
        publicPath: /* 'http://127.0.0.1:' + port + */outputBase + '/'
    },
    externals: {
        react: 'React',
        'react-dom': 'ReactDOM',
        'prop-types': 'PropTypes',
        classnames: 'classNames',
        immutable: 'Immutable',
        // 'react-modal': 'ReactModal',
        // vue: 'Vue',
        vueact: 'Vueact'
    },
    resolve: {
        symlinks: false,
        alias: {
            'react-modal': __dirname + '/src/components/react-modal.jsx'
        }
    },
    module: {
        rules: [{
            test: /\.jsx?$/,
            loader: 'babel-loader',
            include: [
                path.resolve(__dirname, 'src')
            ],
            options: {
                babelrc: false,
                plugins: [
                    ['@babel/plugin-transform-runtime', {
                        helpers: false,
                        regenerator: true
                    }],
                    '@babel/plugin-transform-regenerator',
                    '@babel/plugin-syntax-dynamic-import',
                    '@babel/plugin-proposal-object-rest-spread'
                ],
                presets: ['@babel/preset-env', '@babel/preset-react']
            }
        },
        {
            test: /\.css$/,
            use: [{
                loader: 'style-loader'
            }, {
                loader: 'css-loader',
                options: {
                    modules: true,
                    importLoaders: 1,
                    localIdentName: '[name]_[local]_[hash:base64:5]',
                    camelCase: true
                }
            }, {
                loader: 'postcss-loader',
                options: {
                    ident: 'postcss',
                    plugins() {
                        return [
                            postcssImport,
                            autoprefixer
                        ];
                    }
                }
            }]
        },
        {
            test: /\.less$/,
            use: [
                {
                    loader: 'style-loader'
                },
                {
                    loader: 'css-loader'
                    // options: {
                    //     modules: true,
                    //     importLoaders: 1,
                    //     localIdentName: '[name]_[local]_[hash:base64:5]',
                    //     camelCase: true
                    // }
                },
                {
                    loader: 'less-loader',
                    options: {}
                }
            ]
        }]
    },
    optimization: {
        minimizer: [
            new UglifyJsPlugin({
                include: /\.min\.js$/
            })
        ]
    },
    plugins: []
};

if (!process.env.CI) {
    base.plugins.push(new webpack.ProgressPlugin());
}

module.exports = [
    merge(base, {
        module: {
            rules: [
                {
                    test: /\.(svg|png|wav|gif|jpg)$/,
                    loader: './modules/file-loader',
                    options: {
                        outputPath: 'static/assets/',
                        publicPath: url => {
                            return `__webpack_public_path__ + ${JSON.stringify('static/assets/' + url)}`;
                        }
                    }
                }
            ]
        },
        plugins: [
            new webpack.DefinePlugin({
                'process.env.NODE_ENV': '"' + process.env.NODE_ENV + '"',
                'process.env.DEBUG': Boolean(process.env.DEBUG)
            }),
            new HtmlWebpackPlugin({
                chunks: ['app'],
                template: 'src/index.ejs',
                filename: 'index.html',
                title: 'react-host'
            })
        ]
    }),
    merge(base, {
        target: 'web',
        output: {
            path: path.resolve('dist'),
            publicPath: `${STATIC_PATH}/`
        },
        module: {
            rules: [
                {
                    test: /\.(svg|png|wav|gif|jpg)$/,
                    loader: './modules/file-loader',
                    options: {
                        outputPath: 'static/assets/',
                        publicPath: url => {
                            return `__webpack_public_path__ + ${JSON.stringify('static/assets/' + url)}`;
                        }
                    }
                }
            ]
        }
    })
];

const conf = {
    cdnBase: 'http://tg.xdfstatic.cn/l',
    cdnStatic: '/static/0.1.0/',
    cdnBase2: 'http://127.0.0.1:7035/',
    ejsCdnBase2: '<%=cdnBase2%>',
    publicPath: 'window.config.cdnStatic'
};

module.exports.forEach(config => {
    cdnpub.checkConfig(config, { version, conf });
});

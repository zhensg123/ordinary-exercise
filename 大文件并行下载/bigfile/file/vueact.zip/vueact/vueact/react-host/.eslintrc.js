const path = require('path');

module.exports = {
    root: true,
    extends: ['ali/react', 'plugin:import/errors'],
    env: {
        browser: true,
        node: true
    },
    globals: {
        process: true
    },
    settings: {
        react: {
            version: '16.2' // Prevent 16.3 lifecycle method errors
        },
        'import/resolver': {
            webpack: {
                config: path.resolve(__dirname, '../webpack.config.js')
            }
        }
    },
    rules: {
        'indent': ['error', 4],
        'comma-dangle': ['error', 'never'],
        'import/no-mutable-exports': 'error',
        'import/no-commonjs': 'error',
        'import/no-amd': 'error',
        // 'import/no-nodejs-modules': 'error',
        'import/no-commonjs': 'off',
        'react/jsx-no-literals': 'error',
        'no-confusing-arrow': ['error', {
            'allowParens': true
        }]
    }
};

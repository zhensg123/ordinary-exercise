<template>
    <div class="test">
        {{content || 'no content'}}
    </div>
</template>
<script>
export default {
    name: 'test',
    props: {
        content: {
            type: String,
            default: ''
        }
    }
};
</script>
<style lang="less" scoped>
.test {
    border: 1px solid red;
    margin: 4px;
    padding: 4px 8px;
}
</style>

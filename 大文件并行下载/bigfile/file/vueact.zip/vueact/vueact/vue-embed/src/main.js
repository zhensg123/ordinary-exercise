import Vue from 'vue';
import VueRouter from 'vue-router';
import App from './App.vue';
import routes from './router';
import './assets/reset.less';
import Test from './embed/Test';

function getApp() {
    const router = new VueRouter({
        // base: '/web',
        mode: 'history',
        routes
    });
    return {
        router,
        render: h => h(App)
    };
}

const components = {};
const embed = {
    Test,
    get App() {
        return getApp();
    }
};
export function createVue(name, props) { // createView
    let opts;
    const C = name in components
        ? components[name]
        : (
            opts = embed[name],
            components[name] = Vue.component(opts.name || name, opts)
        );
    // return new C(/* props */); // 这种写法无法传递props属性
    return new Vue({
        render: h => { // 通过自定义render方法实现props传递
            // console.log('-----', h);
            return h(C, { attrs: props });
        }
    });
}

Vue.config.productionTip = false;

Vue.prototype.conf = window.config;
Vue.prototype.console = console;

let instance = null;

function render(props = {}) {
    const { container } = props;
    instance = new Vue(getApp()).$mount(container ? container.querySelector('#app') : '#app');
}

// webpack打包公共文件路径
if (window.microApp) { // __POWERED_BY_QIANKUN__
    __webpack_public_path__ = window.config.cdnBase2; // window.__INJECTED_PUBLIC_PATH_BY_QIANKUN__;
} else { // 独立运行
    render();
}

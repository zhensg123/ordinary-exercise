<template>
    <div class="page-home">
        <h1>HomePage</h1>
    </div>
</template>
<script>
export default {
    name: 'home',
    data() {
        return {
        };
    }
};
</script>
<style lang="less" scoped>
.page-home {
    border: 1px solid red;
    h1 {
        font-size: 16px;
        margin: 0px;
        padding: 4px 8px;
        text-align: center;
    }
}
</style>

<template>
    <div id="app">
        <router-view />
    </div>
</template>
<script>
export default {
    name: 'app',
    data() {
        return {};
    }
}
</script>
<style lang="less">
#app {
    position: relative;
    overflow: hidden;
    font-family: Avenir, Helvetica, Arial, sans-serif;
    color: #2c3e50;
}
</style>

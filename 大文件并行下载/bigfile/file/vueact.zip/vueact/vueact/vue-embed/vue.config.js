const path = require('path');
// const merge = require('webpack-merge');
const cdnpub = require('@xdf/cdnpub');
const AddAssetHtmlPlugin = require('add-asset-html-webpack-plugin');
const { name, version } = require('./package');

function resolve(dir) {
    return path.join(__dirname, dir);
}

const env = process.env.NODE_ENV;
const cdnOrigin = 'http://tg.xdfstatic.cn';
const pathname = `/p/${name}/${version}`;
const conf = {
    mode: 'development',
    port: 7031, // dev port
    cdnBase: `${cdnOrigin}/l`,
    cdnBase2: env === 'development' ? '/' : `${cdnOrigin}${pathname}/`,
    ejsCdnBase2: '<%=cdnBase2%>',
    publicPath: 'window.config.cdnBase2',
    origin: cdnOrigin // http://127.0.0.1:7035
};
const publicPath = conf.origin + pathname;
const json = {
    dllPath: 'public/vendor'
};
const dllPath = './' + json.dllPath;
const linkPath = '/' + json.dllPath.split('/')[1];

module.exports = {
    publicPath: env === 'development' ? '/' : publicPath,
    outputDir: 'dist' + pathname,
    filenameHashing: false,
    devServer: {
        // host: '0.0.0.0',
        host: '127.0.0.1',
        port: conf.port,
        historyApiFallback: true,
        hot: true,
        // disableHostCheck: true,
        overlay: {
            warnings: false,
            errors: true
        },
        // 跨域
        headers: {
            'Access-Control-Allow-Origin': '*'
        },
        before(app) {
            app.use(cdnpub.devlog);
        }
    },
    // 自定义webpack配置
    configureWebpack(config) {
        cdnpub.checkConfig(config, { version, conf });
        config.mode = conf.mode;
        config.plugins.push(
            new AddAssetHtmlPlugin({
                // dll文件位置
                filepath: path.resolve(__dirname, dllPath + '/*.js'),
                // dll 引用路径
                publicPath: publicPath + linkPath,
                // dll最终输出的目录
                outputPath: linkPath
            })
        );
        return {
            // mode: 'development',
            devtool: 'source-map',
            externals: {
                vue: 'Vue',
                'vue-router': 'VueRouter',
                vuex: 'Vuex',
                'element-ui': 'ELEMENT',
                axios: 'axios',
                moment: 'moment'
                // echarts: 'echarts'
            },
            resolve: {
                alias: {
                    '@': resolve('src')
                }
            },
            output: {
                // 把应用打包成 umd 库格式
                // publicPath,
                library: `${name}-[name]`,
                libraryTarget: 'umd',
                jsonpFunction: `webpackJsonp_${name}`
            }
        };
    }
};
